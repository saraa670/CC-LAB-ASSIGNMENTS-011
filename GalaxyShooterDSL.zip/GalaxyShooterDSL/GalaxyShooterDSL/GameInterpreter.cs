﻿using System;
using System.Collections.Generic;

namespace GalaxyShooterDSL
{
    public class GameInterpreter
    {
        public void Interpret(List<GameElement> elements)
        {
            foreach (var element in elements)
            {
                if (element is Ship ship)
                {
                    Console.WriteLine($"Creating ship: {ship.Name} with Health: {ship.Properties["Health"]}, Speed: {ship.Properties["Speed"]}, Weapon: {ship.Properties["Weapon"]}");
                }
                else if (element is EnemyWave wave)
                {
                    Console.WriteLine($"Spawning {wave.Properties["Count"]} enemies of type {wave.Properties["Type"]} every {wave.Properties["Interval"]} seconds.");
                }
                else if (element is PowerUp powerUp)
                {
                    Console.WriteLine($"Generating power-up: {powerUp.Name} with effect: {powerUp.Properties["Effect"]} for {powerUp.Properties["Duration"]} seconds.");
                }
                else if (element is Level level)
                {
                    Console.WriteLine($"Configuring Level {level.LevelNumber}...");
                    Console.WriteLine($"   Enemies: {level.Properties["Enemies"]}");
                    Console.WriteLine($"   PowerUps: {level.Properties["PowerUps"]}");
                }
            }
        }
    }
}

