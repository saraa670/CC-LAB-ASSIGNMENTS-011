﻿using System;
using System.Collections.Generic;

namespace GalaxyShooterDSL
{
    class Program
    {
        static void Main(string[] args)
        {
            var script = @"
            Ship ""PlayerShip"" {
                Health = 100
                Speed = 10
                Weapon = ""Laser""
            }

            EnemyWave {
                Type = ""Alien""
                Count = 5
                Interval = 2
            }

            PowerUp ""Shield"" {
                Duration = 10
                Effect = ""IncreaseDefense""
            }

            Level 1 {
                Enemies = [EnemyWave]
                PowerUps = [Shield]
            }";

            // Parse the DSL script
            var parser = new DSLParser();
            var elements = parser.Parse(script);

            // Interpret and generate game elements
            var interpreter = new GameInterpreter();
            interpreter.Interpret(elements);
        }
    }
}

