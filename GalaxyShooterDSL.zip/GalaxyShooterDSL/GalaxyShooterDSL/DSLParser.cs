﻿using System;
using System.Collections.Generic;

namespace GalaxyShooterDSL
{
    public class DSLParser
    {
        public List<GameElement> Parse(string script)
        {
            var elements = new List<GameElement>();
            var lines = script.Split('\n');
            GameElement currentElement = null;

            foreach (var line in lines)
            {
                var trimmed = line.Trim();
                if (string.IsNullOrEmpty(trimmed)) continue;

                if (trimmed.StartsWith("Ship"))
                {
                    currentElement = new Ship();
                    currentElement.Name = trimmed.Split('"')[1];
                }
                else if (trimmed.StartsWith("EnemyWave"))
                {
                    currentElement = new EnemyWave();
                }
                else if (trimmed.StartsWith("PowerUp"))
                {
                    currentElement = new PowerUp();
                    currentElement.Name = trimmed.Split('"')[1];
                }
                else if (trimmed.StartsWith("Level"))
                {
                    currentElement = new Level { LevelNumber = int.Parse(trimmed.Split(' ')[1]) };
                }
                else if (trimmed.Contains("=") && currentElement != null)
                {
                    var parts = trimmed.Split('=');
                    var key = parts[0].Trim();
                    var value = parts[1].Trim().Trim('"');
                    currentElement.Properties[key] = value;
                }
                else if (trimmed.StartsWith("}"))
                {
                    if (currentElement != null) elements.Add(currentElement);
                    currentElement = null;
                }
            }
            return elements;
        }
    }

    public abstract class GameElement
    {
        public string Name { get; set; }
        public Dictionary<string, string> Properties { get; } = new Dictionary<string, string>();
    }

    public class Ship : GameElement { }
    public class EnemyWave : GameElement { }
    public class PowerUp : GameElement { }
    public class Level : GameElement
    {
        public int LevelNumber { get; set; }
    }
}


