﻿using System;
using System.Collections.Generic;

class SLRParser
{
    static void Main(string[] args)
    {
        // Grammar
        string[] grammar = {
            "E -> E + T",
            "E -> T",
            "T -> T * F",
            "T -> F",
            "F -> ( E )",
            "F -> id"
        };

        // SLR Parsing Table
        Dictionary<(string, string), string> parsingTable = new Dictionary<(string, string), string>
        {
            { ("0", "id"), "S5" },
            { ("0", "("), "S4" },
            { ("1", "+"), "S6" },
            { ("1", "$"), "Accept" },
            { ("2", "*"), "S7" },
            { ("2", "+"), "R2" },
            { ("2", "$"), "R2" },
            // Add more states and actions based on grammar rules
        };

        // Stack Initialization
        Stack<string> stack = new Stack<string>();
        stack.Push("0");

        string input = "id + id $"; 
        string[] tokens = input.Split(' ');

        int pointer = 0;
        while (pointer < tokens.Length)
        {
            string currentState = stack.Peek();
            string currentToken = tokens[pointer];

            if (!parsingTable.ContainsKey((currentState, currentToken)))
            {
                Console.WriteLine("Error: Invalid input sequence.");
                return;
            }

            string action = parsingTable[(currentState, currentToken)];
            if (action.StartsWith("S"))
            {
                stack.Push(currentToken);
                stack.Push(action.Substring(1));
                pointer++;
            }
            else if (action.StartsWith("R"))
            {
                // Reduction logic (to be implemented based on grammar)
                Console.WriteLine($"Reduce using rule {action}");
            }
            else if (action == "Accept")
            {
                Console.WriteLine("Input accepted.");
                return;
            }
        }
    }
}

