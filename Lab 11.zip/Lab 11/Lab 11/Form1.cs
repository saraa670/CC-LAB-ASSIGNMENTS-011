﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Lab_11
{
    public partial class Form1 : Form
    {
        // Symbol table to store variables and their details
        private List<List<string>> SymbolTable = new List<List<string>>();
        private List<int> Constants = new List<int>(); // For constant tracking

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Form load event (can be used for initialization if needed)
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // This event is not used for now, but it's ready if needed
        }

        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            string code = txtCode.Text;
            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Please enter valid code.", "Error");
                return;
            }

            string[] lines = code.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            SymbolTable.Clear();
            dgvSymbolTable.Rows.Clear();
            lstOutput.Items.Clear();

            foreach (string line in lines)
            {
                ProcessLine(line.Trim());
            }

            UpdateSymbolTable();
        }

        private void ProcessLine(string line)
        {
            // Regular expressions for variable declarations and operations
            Regex declarationRegex = new Regex(@"^(int|float) ([a-zA-Z_]\w*) = (\d+)$");
            Regex operationRegex = new Regex(@"^([a-zA-Z_]\w*) = ([a-zA-Z_]\w*) ([+\-]) ([a-zA-Z_]\w*)$");

            // Check for variable declarations
            Match declMatch = declarationRegex.Match(line);
            if (declMatch.Success)
            {
                string type = declMatch.Groups[1].Value;
                string variable = declMatch.Groups[2].Value;
                string value = declMatch.Groups[3].Value;

                AddToSymbolTable(variable, type, value);
                lstOutput.Items.Add($"Variable declared: {variable} = {value} ({type})");
                return;
            }

            // Check for arithmetic operations
            Match opMatch = operationRegex.Match(line);
            if (opMatch.Success)
            {
                string leftSide = opMatch.Groups[1].Value;
                string operand1 = opMatch.Groups[2].Value;
                string operation = opMatch.Groups[3].Value;
                string operand2 = opMatch.Groups[4].Value;

                PerformOperation(leftSide, operand1, operation, operand2);
                return;
            }

            lstOutput.Items.Add($"Invalid syntax: {line}");
        }

        private void AddToSymbolTable(string variable, string type, string value)
        {
            foreach (var row in SymbolTable)
            {
                if (row[0] == variable)
                {
                    lstOutput.Items.Add($"Error: Variable {variable} already declared.");
                    return;
                }
            }

            SymbolTable.Add(new List<string> { variable, type, value });
        }

        private void PerformOperation(string leftSide, string operand1, string operation, string operand2)
        {
            int value1 = GetVariableValue(operand1);
            int value2 = GetVariableValue(operand2);

            if (value1 == int.MinValue || value2 == int.MinValue)
            {
                lstOutput.Items.Add($"Error: Undefined variables in operation {operand1} {operation} {operand2}");
                return;
            }

            int result = operation == "+" ? value1 + value2 : value1 - value2;

            UpdateVariableValue(leftSide, result);
            lstOutput.Items.Add($"{leftSide} = {operand1} {operation} {operand2} -> {result}");
        }

        private int GetVariableValue(string variable)
        {
            foreach (var row in SymbolTable)
            {
                if (row[0] == variable)
                {
                    return int.Parse(row[2]);
                }
            }
            return int.MinValue; // Undefined variable
        }

        private void UpdateVariableValue(string variable, int value)
        {
            foreach (var row in SymbolTable)
            {
                if (row[0] == variable)
                {
                    row[2] = value.ToString();
                    return;
                }
            }

            // If variable not found, add it
            SymbolTable.Add(new List<string> { variable, "int", value.ToString() });
        }

        private void UpdateSymbolTable()
        {
            foreach (var row in SymbolTable)
            {
                dgvSymbolTable.Rows.Add(row.ToArray());
            }
        }
    }
}
