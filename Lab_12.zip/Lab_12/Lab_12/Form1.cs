﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Lab_12
{
    public partial class Form1 : Form
    {
        // Symbol Table as a list of tokens
        private List<(string Token, string Type)> SymbolTable = new List<(string Token, string Type)>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            // Clear previous results
            dgvSymbolTable.Rows.Clear();
            lstOutput.Items.Clear();
            SymbolTable.Clear();

            string code = txtCode.Text;
            if (string.IsNullOrWhiteSpace(code))
            {
                MessageBox.Show("Please enter valid code.", "Error");
                return;
            }

            // Tokenize and process the input code
            string[] lines = code.Split(new[] { '\n', ';' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines)
            {
                AnalyzeLine(line.Trim());
            }

            // Populate the symbol table in DataGridView
            foreach (var entry in SymbolTable)
            {
                dgvSymbolTable.Rows.Add(entry.Token, entry.Type);
            }

            lstOutput.Items.Add("Lexical analysis completed.");
        }

        private void AnalyzeLine(string line)
        {
            // Define regular expressions
            Regex keywordRegex = new Regex(@"\b(int|float|if|else|while|return)\b");
            Regex identifierRegex = new Regex(@"\b[a-zA-Z_]\w*\b");
            Regex constantRegex = new Regex(@"\b\d+(\.\d+)?\b");
            Regex operatorRegex = new Regex(@"[+\-*/=<>]");

            // Split the line into tokens
            string[] tokens = line.Split(new[] { ' ', '(', ')', '{', '}', '=', '+', '-', '*', '/', ';' },
                                         StringSplitOptions.RemoveEmptyEntries);

            foreach (string token in tokens)
            {
                if (keywordRegex.IsMatch(token))
                {
                    AddToSymbolTable(token, "Keyword");
                }
                else if (constantRegex.IsMatch(token))
                {
                    AddToSymbolTable(token, "Constant");
                }
                else if (operatorRegex.IsMatch(token))
                {
                    AddToSymbolTable(token, "Operator");
                }
                else if (identifierRegex.IsMatch(token))
                {
                    AddToSymbolTable(token, "Identifier");
                }
                else
                {
                    lstOutput.Items.Add($"Unrecognized token: {token}");
                }
            }
        }

        private void AddToSymbolTable(string token, string type)
        {
            // Avoid duplicates in the symbol table
            if (!SymbolTable.Exists(entry => entry.Token == token))
            {
                SymbolTable.Add((token, type));
            }
        }
    }
}
